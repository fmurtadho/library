1. cd / change directory
2. ls / liat ada file atau folder apa saja di directory kita
3. pwd / liat posisi kita ada directory mana
4. mkdir <name folder>  / buat folder
5. touch <name file> / buat file
6. rm <name file> / remove file atau delete
7. cp <name file> <name file baru> / copy file
8. mv <name file> <directory kemana> / move file