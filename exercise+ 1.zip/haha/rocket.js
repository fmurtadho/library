/*

Buatlah pola bilangan berikut menggunakan rekursif,
tidak usah buat function

54321
5432
543
54
5


321
32
3

*/